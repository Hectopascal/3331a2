import java.io.*;
import java.text.*;
import java.util.*;

/* Reads and parses input
 * Prints output if request/cancel/change failed
 * Prints output for successful cancellation
 */
public class VenueHireSystem {
	public static Hashtable<String, Bookings> bookings = new Hashtable<String, Bookings>();
	public static Map<String, Venues> venList = Collections.synchronizedMap( new LinkedHashMap<String, Venues>());
	
	public static void main(String[] args) throws CloneNotSupportedException {
		Scanner sc = null;
	    try {
	        sc = new Scanner(new FileReader(args[0])); 
	        while(sc.hasNextLine()){
	        	
		    	String line = sc.nextLine();
		    	String[] words = line.split("\\s");
		    	String command = words[0];
		    	
		    	if (command.equals("Venue")){
		    		String venName = words[1];
		    		String roomName = words[2];
		    		String roomSize = words[3];
		    		if (venList.containsKey(venName)){ //if venue does not exist
		    			Venues toChange = (Venues) venList.get(venName);
		    			toChange.addRoom(roomName, roomSize);
		    		} else{
		    			venList.put(venName, new Venues(venName,roomName,roomSize));
		    		}
		    	
		    	} else if (command.equals("Request") || command.equals("Change")){
		    		modBooking(words);
		    		
		    	} else if (command.equals("Cancel")){
		    		
		    		if(bookings.containsKey(words[1])){
		    			((Bookings) bookings.get(words[1])).removeBooking();
		    			bookings.remove(words[1]);
		    			System.out.println("Cancel "+words[1]);
		    		} else {
		    			System.out.println("Cancel rejected");
		    		}

		    	} else if (command.equals("Print")){
		    		String name = words[1];
		    		Venues toPrint = venList.get(name);
		    		toPrint.printBookings();
		    	} else {
		    		//unrecognised command
		    	}

		    }  
	    } catch (FileNotFoundException e) {	
	    } finally {
	        if (sc != null) sc.close();
	    }
	}
		
	private static void modBooking(String[] details) throws CloneNotSupportedException{
		int[] sizeReq  = new int[3]; 
		String id = details[1];
		
		//check if id exists
		if(details[0].equals("Change") && !bookings.containsKey(id)){
			System.out.println("Change rejected");
			return;
		}
		if(details[0].equals("Request") && bookings.containsKey(id)){ 
			System.out.println("Request rejected");
			return;
		}
		
		//parse calendar dates
		Calendar from = dateFormatter(details[2],details[3]);
		Calendar to = dateFormatter(details[4],details[5]);
		if(to.before(from)){
			System.out.println(details[0]+" rejected");
			return;
		}
		//collect requested sizes
		int i;
		for (i=6; i<details.length; i+=2){
			if (details[i+1].equals("small")) {
				sizeReq[0]+= Integer.parseInt(details[i]);
			} else if (details[i+1].equals("medium")) {
				sizeReq[1]+= Integer.parseInt(details[i]);
			} else if (details[i+1].equals("large")){
				sizeReq[2]+= Integer.parseInt(details[i]);
			}
		}
		
		
		Bookings initial = null;
		if(details[0].equals("Change")){ 
			initial = (Bookings) bookings.get(id).clone();
			initial.removeBooking(); 
			bookings.remove(id);
		}
		
		//CHECK AVAILABILITY (and book)
		Set<String> keySet = venList.keySet();
		Iterator<String> it = keySet.iterator();
		
		while(it.hasNext()){
			String key = it.next();
			Bookings newBook = ((Venues)venList.get(key)).checkAvailable(details[0], sizeReq,from, to, id);
			if( newBook != null) {
				bookings.put(id, newBook); 
				return;
			}
			i++;
		}
		
		if(details[0].equals("Request")){
			System.out.println("Request rejected");
		} else {
			bookings.put(id, initial);
			initial.restoreBooking();
			System.out.println("Change rejected");
		}
		return;
	}
    /*string to calendar formatter*/
	private static Calendar dateFormatter(String M, String D){
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy MMM d",Locale.ENGLISH); 
		String dateString = "2016 "+M+" "+D;
		Calendar formatted =  Calendar.getInstance();
		try{
			formatted.setTime(dateformat.parse(dateString));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formatted;
	}
}
