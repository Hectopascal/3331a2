import java.util.*;
public class Bookings implements Cloneable{
	private String venue;
	private String id;
	private Calendar start;
	private Calendar end;
	private ArrayList<Room> rooms = new ArrayList<Room>();
	
	// calls room method to change occupied dates and prints bookings
	public Bookings(String id, Calendar start, Calendar end, String req, List<Integer> toBook, Venues venue){
		this.id = id;
		this.start = start;
		this.end = end;
		this.venue = venue.name;
		if(req.equals("Request")) req = "Reservation";
		System.out.print(req + " " + this.id + " " + this.venue);
		for(int n =0; n<toBook.size(); n++){
			if(n != toBook.size()){
				System.out.print(" ");
			}
			Room addDates = venue.getRoom(toBook.get(n));
			addDates.bookRoom(start,end);
			rooms.add(addDates);
			System.out.print(addDates.name);
		}
		System.out.println("");
		return;
	}
	//put occupied dates back into room 
	//used for restoring old booking in event of failed change
	public void restoreBooking(){
		for(int n =0; n<rooms.size(); n++){
			rooms.get(n).bookRoom(start,end);
		}
	}
	
	//remove booking for each room booked
	public void removeBooking(){
		for(int i = 0; i<rooms.size(); i++){
			((Room) rooms.get(i)).removeDates(start, end);
		}
		return;
	}
	
	//clone
	@Override
	public Object clone() throws CloneNotSupportedException {
	    return super.clone();
	}
	
}
