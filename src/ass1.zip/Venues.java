import java.util.*;


public class Venues {
	public static final int LAR = 2;
	public static final int MED = 1;
	public static final int SMA = 0;
	public String name;
	private ArrayList<Room> roomList = new ArrayList<Room>();
	private int[] roomSizes = new int[3];
	
	/* CONSTRUCTOR */
	public Venues(String name, String roomName, String size) {
		this.name = name;
		this.addRoom(roomName, size);
	}
	
	//ADDS AND COUNTS ROOMS
	public void addRoom(String roomName, String size){
		for(int i = 0; i<roomList.size();i++){
			if(roomList.get(i).name == roomName) //if room already exists
				return;
		}
		if(size.equals("large")) roomSizes[LAR]++;
		if(size.equals("medium")) roomSizes[MED]++;
		if(size.equals("small")) roomSizes[SMA]++;
		
		Room newRoom = new Room(size, roomName);
		
		roomList.add(newRoom);
	}
	
	
	//CHECKS AVAIABILITY AND BOOKS
	public Bookings checkAvailable(String type, int[] request, Calendar from, Calendar to, String id){
		int lar = request[LAR]; /* save no. of each request to count */
		int med = request[MED];
		int sma = request[SMA];
		int total = lar+med+sma;
		List<Integer> toBook = new ArrayList<Integer>();

		if(roomSizes[LAR]<lar || roomSizes[MED]<med || roomSizes[SMA]<sma)
			return null; //early exit if insufficient rooms
		
		for(int i = 0; i<roomList.size(); i++){
			Room checking = roomList.get(i);
			if(sma > 0 && checking.size.equals("small")  && checking.checkRoom(from,to)){
				toBook.add(i);
				sma--;
				total--;
			}else if(med > 0 && checking.size.equals("medium")  && checking.checkRoom(from,to)){
				toBook.add(i);
				med--;
				total--;
			}else if(lar > 0 && checking.size.equals("large")  && checking.checkRoom(from,to)){
				toBook.add(i);
				lar--;
				total--;
			}
		}		
		
		if(total > 0) return null; //still has unfulfilled requests
		
		//If not returned at this point, make booking.
		Bookings book = new Bookings(id, from, to, type,toBook,this);

		return book;
	}
	
	/* Return a room from list index */
	public Room getRoom(int roomIndex){
		Room requested = roomList.get(roomIndex);
		return requested;
	}
	/*Print*/
	public void printBookings(){
		for(int i =0; i<roomList.size(); i++){
			Room toPrint = roomList.get(i);
			System.out.print(this.name+" "+toPrint.name);
			toPrint.printDates();
			System.out.println("");
		}
	}
}
