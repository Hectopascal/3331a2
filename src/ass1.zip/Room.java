import java.util.*;
import java.text.*;


/* Calculates differences between start and end dates
 * changes and modifies dates occupied
 */
public class Room {
	public static final int REQ_YEAR = 2016;
	public String name;
	public String size;
	private TreeMap<Integer, Integer> occDates = new TreeMap<Integer, Integer>();
	
	/*CONSTRUCTOR*/
	public Room(String size, String name) {
		this.size = size;
		this.name = name;
	}
	
	//check occupied dates
	public boolean checkRoom(Calendar from, Calendar to){
		int startCheck = from.get(Calendar.DAY_OF_YEAR);  
		int endCheck = to.get(Calendar.DAY_OF_YEAR);
		
		for(Map.Entry<Integer,Integer> entry : occDates.entrySet()) {
			  Integer startOcc = entry.getKey();
			  Integer endOcc = entry.getValue() + startOcc-1;
			// if x1<= y2 and y1<=x2, ranges overlap.
			  if(startCheck <= endOcc && startOcc <= endCheck)
				  return false;
		}

		return true;
	}
	//adds occupied dates 
	public void bookRoom(Calendar from, Calendar to){
		int startDay = from.get(Calendar.DAY_OF_YEAR);
		int dur = calcDays(from,to);
		this.occDates.put(startDay, dur);	
	}
	
	//removes occupied dates
	public void removeDates(Calendar from, Calendar to){
		int startDay = from.get(Calendar.DAY_OF_YEAR);
		occDates.remove(startDay);
	
	}
	
	// print occupied dates for room
	public void printDates(){
		Calendar calDate = Calendar.getInstance();
		SimpleDateFormat printFormat = new SimpleDateFormat("MMM d", Locale.ENGLISH);
		
		Set<Integer> keys = occDates.keySet();
		for (Iterator<Integer> i = keys.iterator(); i.hasNext();) {
			
			int startDate = (int) i.next();
			int duration = (int) occDates.get(startDate);
			calDate.set(Calendar.DAY_OF_YEAR, startDate);
			calDate.set(Calendar.YEAR, REQ_YEAR);
			System.out.print(" "+printFormat.format(calDate.getTime())+ " " + duration);
			
		   }
		
		/* for(Map.Entry<Integer,Integer> entry : occDates.entrySet()) {
			int startDate = entry.getKey();
			calDate.set(Calendar.DAY_OF_YEAR, startDate);
			calDate.set(Calendar.YEAR, REQ_YEAR);
			System.out.print(printFormat.format(calDate.getTime()) );
		} */
		
	}
	
	//calculate number of days occupied
	private int calcDays(Calendar start, Calendar end){
		int diff = 0;

		int startDay = start.get(Calendar.DAY_OF_YEAR);  
		int endDay = end.get(Calendar.DAY_OF_YEAR);
		diff = endDay - startDay + 1;

		return diff;
	}
}
