import java.util.*;
public class State implements Comparable<State> {

	private Trip current;
	private int gCost;
	private State prevState;
	private ArrayList<Trip> remaining;
	
	
	/**
	 * State Constructor
	 * 
	 * @param cNode
	 *            the current City/Node
	 * @param cost
	 *            the cost so far
	 * @param pState
	 *            prev state
	 */
	public State(Trip tripNode, int cost, State pState, ArrayList<Trip> r) {
		current = tripNode;
		gCost = cost;
		prevState = pState;
		remaining = new ArrayList<Trip>(r);
	}

	@Override
	public int compareTo(State s) {
		return calcFCost() - s.calcFCost();
	}

	private int calcFCost() {
		RemainingDist rd = new RemainingDist();
		return gCost + rd.rDistance(this);
	}

	public Trip getTrip() {
		return current;
	}
	
	
	public int getCostSoFar() {
		return gCost;
	}
	
	public ArrayList<Trip> getRemain(){
		return remaining;
		
	}
	
	
	public State getPrev(){
		return prevState;
	}
	
	public void printCurrent() {
		System.out.println("cost = "+ gCost);
		List<State> l = new LinkedList<State>();
		makePath(this,l);
		Collections.reverse(l);
		State prev = null;
		for(State s : l){
			if(prev != null && !prev.current.to.equals(s.current.from)){
				System.out.println("Trip " + prev.current.to + " to " + s.current.from);
			}
			System.out.println("Trip " + s.current.from + " to " + s.current.to);
			
			prev = s;
		}
	}
	/**
	 * Recursive method to print the path out using previous states
	 * 
	 * @param s
	 *            the string to append to
	 * @return an appended string
	 */
	private void makePath(State s, List<State> l) {
		if(s.current.from != null){
			l.add(s);
			makePath(s.prevState,l);
		}
		
	}
	


}
