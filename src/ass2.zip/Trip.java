/**
 * 
 */

/**
 * @author z5013079
 *
 */
public class Trip {
	public String to;
	public String from;
	private Integer cost;
	private Integer toT;
	private Integer fromT;
	/**
	 * New trip constructor
	 * @param to
	 * 		Destination city
	 * @param from
	 * 		City starting from
	 * @param cost
	 * 		distance of trip
	 */
	public Trip(String from, String to, Integer distance) {
		super();
		this.to = to;
		this.from = from;
		this.cost = distance;
	}


	/**
	 * @return the toT
	 */
	public Integer getToT() {
		return toT;
	}


	/**
	 * @param toT the toT to set
	 */
	public void setToT(Integer toT) {
		this.toT = toT;
	}


	/**
	 * @return the fromT
	 */
	public Integer getFromT() {
		return fromT;
	}


	/**
	 * @param fromT the fromT to set
	 */
	public void setFromT(Integer fromT) {
		this.fromT = fromT;
	}


	/**
	 * Get cost of the trip
	 * @return the cost
	 */
	public Integer getCost() {
		return cost;
	}
	
	public boolean compareTo(String end, String start){
		return (end.equals(to) && start.equals(from));
	}
	
}
