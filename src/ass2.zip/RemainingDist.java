import java.util.ArrayList;

public class RemainingDist implements Heuristic{

	/**
	 * Heuristic calculation function
	 * adds the cost of the remaining trips together as hCost.
	 * I can't believe I finished this assignment omg ;u; 
	 * @param s
	 * 		node to check
	 * @return
	 */
	public int rDistance(State s) {
		int heur = 0;
		ArrayList<Trip> all = s.getRemain();
		for(Trip t : all){
			heur += t.getCost()+t.getFromT();
		}
		return heur;
	}	
	
}
