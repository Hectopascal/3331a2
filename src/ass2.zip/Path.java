
/**
 * @author Vancratt
 *
 */
public class Path {
	public String city1;
	public String city2;
	public Integer time;

	/**
	 * @param city1
	 * @param city2
	 * @param time
	 */ 
	public Path(Integer time, String city1, String city2) {
		super();
		
		this.city1 = city1;
		this.city2 = city2;
		this.time = time;
	}
	/**
	 * Method to return the other end of an edge. 
	 * @param name
	 * 		name of starting end
	 * @return
	 */
	public String getOtherEnd(String name) {
		if (city1.equals(name)) return city2;
		else if (city2.equals(name)) return city1;
		
		return null;
	}
	
	
}
