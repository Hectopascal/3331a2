/**
 * 
 */

/**
 * @author Vancratt
 *
 */
public interface Heuristic {
	public int rDistance(State s);
}
