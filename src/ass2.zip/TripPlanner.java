import java.util.*;
import java.io.*;
import java.text.*;
/**
 * TripPlanner class with main function.
 * @author z5013079
 *
 */
public class TripPlanner {
	public HashMap<String,Integer> cities = new HashMap<String,Integer>();
	public ArrayList<Path> paths = new ArrayList<Path>();
	public ArrayList<Trip> compulsory = new ArrayList<Trip>();
	
	/**
	 * Creates new TripPlanner object.
	 * @param f
	 * 		input file
	 */
	public TripPlanner(File f) {
		Scanner sc = null;
	    try {
	        sc = new Scanner(new FileReader(f)); 
	        
	        //save all scanner input
	        while(sc.hasNextLine()){
		    	String line = sc.nextLine();
		    	String[] words = line.split("\\s");
		    	String command = words[0];
		    	
		    	if (command.equals("Transfer")){
		    		String name = words[2];
		    		Integer time = Integer.parseInt(words[1]);
		    		cities.put(name,time);
		    	} else if (command.equals("Time")){
		    		Path p = new Path(Integer.parseInt(words[1]),words[2],words[3]);
		    		paths.add(p);
		    	} else if (command.equals("Trip")){
		    		Path correct = null;
		    		for(int i = 0; i<paths.size(); i++){ //find corresponding edge
		    			Path p = paths.get(i);
		    			if( (p.city1.equals(words[1]) && p.city2.equals(words[2])) || ( p.city1.equals(words[2]) && p.city2.equals(words[1])) ){
		    				correct = p;
		    				break;
		    			}
		    		}
		    		Trip t = new Trip(words[1],words[2], correct.time);
		    		t.setFromT(cities.get(t.from));
		    		t.setToT(cities.get(t.to));
		    		compulsory.add(t);
		    	} else {
		    		//unrecognised command
		    	}

		    }  
	        
	    } catch (FileNotFoundException e) {	
	    } finally {
	        if (sc != null) sc.close();
	    }
	    Trip newTrip = new Trip(null,"London",0);
	    aStar(newTrip);
	   
	}

	
	/** 
	 * Prints out saved cities, paths and required trips
	 * 
	 */
	private void printAll() {
		System.out.println("/-----Cities and time------/");
		Iterator it = cities.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String,Integer> pair = (Map.Entry<String,Integer>) it.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());
		}

		System.out.println("/----Paths-----/");
		for (int i = 0; i < paths.size(); i++) {
			Path pa = paths.get(i);
			System.out.println(pa.city1 + " " + pa.city2 + " " + pa.time.toString());
		}
		System.out.println("/---- Required ------/");
		for (int i = 0; i < compulsory.size(); i++) {
			Trip t = compulsory.get(i);
			System.out.println(t.from + " " + t.to);
		}

		System.out.println("/----End of information----/");
		
		//System.out.println(aStar(newTrip));
	}
	/**
	 * For debugging. Prints out statuses of current and next(option) node.
	 * Meant to be used inside aStar.
	 * @param cur
	 * 		the node you're going from
	 * @param next
	 * 		the node you're going to
	 * @param transfer
	 * 		the 'extra' cost that was calculated in astar
	 */
	private void printCurrentStats(State cur, State next, Integer transfer){
		System.out.println("Starting at: ");
		System.out.println(cur.getTrip().from + " to " + cur.getTrip().to);
		System.out.println("Cost: "+ cur.getCostSoFar());
		System.out.println("Remaining trips: ");
		for(Trip t : cur.getRemain()){
			System.out.println(t.from + " to " + t.to);
		}
		System.out.println("Moving with extra cost of " + transfer);
		System.out.println(next.getTrip().from + " to " + next.getTrip().to);
		System.out.println("Cost: "+ next.getCostSoFar());
		System.out.println("Remaining trips: ");
		for(Trip t : next.getRemain()){
			System.out.println(t.from + " to " + t.to);
		}
		System.out.println("--------");
	}
	
	
	/**
	 * aStar searching, returns cost of optimal path
	 * @param start
	 * 		City to start at
	 * @param end
	 * 		City to end at
	 * @return
	 */
	private Integer aStar(Trip start) {
		State best = null;
		Integer completeFlag = 0;
		
		PriorityQueue<State> q = new PriorityQueue<State>(); //queue
		State currentState = new State(start, 0, null, compulsory); //current
		q.add(currentState);
		int counter = 0;
		while (!q.isEmpty()) {
			counter++;
			State current = q.poll();
			Trip curLoc = current.getTrip();
			
			if(completeFlag == 1){
				if(current.getCostSoFar() < best.getCostSoFar() && current.getRemain().size() == 0){
					best = current;
					continue;
				} else if (current.getCostSoFar() >= best.getCostSoFar()) {
					System.out.println(counter + " nodes expanded");
					best.printCurrent();
					return best.getCostSoFar();
				} 
			}
			
			ArrayList<Trip> options = new ArrayList<Trip>(current.getRemain());
			Iterator<Trip> iter = options.iterator();
			while (iter.hasNext()) {
				Trip option = iter.next();
				int extra = 0;
				if(curLoc != start) {
					extra += cities.get(curLoc.to);
				}
				if(!curLoc.to.equals(option.from)){
					for(Path p : paths){
						if(p.getOtherEnd(curLoc.to) != null && p.getOtherEnd(curLoc.to).equals(option.from)){
							
							extra += cities.get(option.from) + p.time;
							break;
						}
					}
				}
				
				ArrayList<Trip> temp = new ArrayList<Trip>(current.getRemain());
				temp.remove(option);
				State state = new State(option, option.getCost()+ extra + current.getCostSoFar(), current, temp);
				
				State old = null;
				for (State cur : q) {
					if (cur.getRemain().equals(state.getRemain())) {
						old = cur; 
						break;
					}
				}
				if(completeFlag == 0 && state.getRemain().size() == 0){
					best = state;
					completeFlag = 1;
					continue;
				}
			
				q.add(state);
				if (old != null && (state.compareTo(old) < 0)) q.remove(old);
			}
		}
		
		
		return -1;
	}
	
	
	/**
	 * Recursive method to put states into Linked list
	 * @param l
	 * 		Linked list to add states to
	 * @param cur
	 * 		current state
	 */
	private void findFullTrip(LinkedList<State> l, State cur){
		if(cur != null){
			l.add(cur);
			System.out.println(cur.getTrip().to);
			findFullTrip(l,cur.getPrev());
		}
		return;
	}
	
	/**
	 * Main function; takes input and creates new TripPlanner object
	 * @param args
	 */
	public static void main(String[] args) {
				
		  Scanner sc = null;
		  try
		  {
			  sc = new Scanner(new FileReader(args[0]));
			  new TripPlanner(new File(args[0]));
		  }
		  catch (FileNotFoundException e) {}
		  finally
		  {
		      if (sc != null) sc.close();
		  }
	}

}
